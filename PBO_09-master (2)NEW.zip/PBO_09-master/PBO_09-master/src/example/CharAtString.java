package example;

public class CharAtString {
    
    public static void main(String []args){
        String name = "Mangcoding";
        System.out.println("The result is the letters: " + name.charAt(4));
    }
}
