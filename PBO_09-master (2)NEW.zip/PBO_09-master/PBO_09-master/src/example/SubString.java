package example;

public class SubString {
    public static void main(String[] args) {
        String hello = "Welcome to mangcoding";
        System.out.println("The result is: " + hello.substring(0, 0));
        System.out.println("The result is: " + hello.substring(5, hello.length()));
    }
}
